# QUICK CONTEXT CARD - Santi Management V2

## Tech Stack
Next.js 14.2.25 + Clerk Auth + Single-file architecture (app/page.js)

## Hierarchy
```
Building Sequence (sidebar parent)
├── Villa 3, Villa 2, Villa 1, Studio 3 (standalone projects)
├── + Add Project (admin only)
├── COMMONS / INFRASTRUCTURE (section header)
│   ├── Parking, Main Water, Landscaping, etc. (zones)
│   └── + Add Zone (admin only)
```

## Navigation IDs
- `project-villa3` → Villa 3
- `zone-parking` → Parking / Entrance
- `getCurrentProject()` extracts label for filtering

## Data Link
`buildingTasks.villa` = project label (e.g., "Villa 3", "Parking / Entrance")

## Permissions
- **Admin (Patrick)**: Direct edits, sees Pending Approvals, can Add Project/Zone
- **Non-Admin**: All edits → pending proposals, sees My Suggestions

## Key State
```javascript
buildingSequences: { standalone: [...], commons: { label, zones: [...] } }
buildingTasks: [{ villa, subCategory (phase), step, task, ... }]
pendingChanges: [{ type, requestedBy, status: 'pending'|'approved'|'rejected' }]
```

## Views (based on activeNav)
- `taskBoard` → Kanban
- `recurring` → Recurring Tasks
- `project-*` or `zone-*` → Building Sequence table
- `schedule` → Daily Worker Schedule (3-day)
- `pendingApprovals` → Admin review queue
- `mySuggestions` → Non-admin proposals

## Current Session Work
1. Restructured sidebar - Building Sequence as single expandable parent
2. Added Commons/Infrastructure as section header (not nested dropdown)
3. Admin-only controls for Add Project/Zone
4. Pending Approvals with Approve All button
5. My Suggestions view for non-admins

## Files Included
- `page.js` - Complete application (1916 lines)
- `HANDOFF-2026-01-08.md` - Full documentation
